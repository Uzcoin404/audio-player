let audioList = [
    {
        name: "FOUNDATION master",
        artist: "Unknown",
        description: "Lorem ipsum dolor sit amet.",
        src: "../../audio/FOUNDATION-master.mp3",
    },
    {
        name: "lightning",
        artist: "Unknown",
        description: "Lorem ipsum dolor sit amet.",
        src: "../../audio/lightning.mp3",
    },
    {
        name: "Oblivion master",
        artist: "Unknown",
        description: "Lorem ipsum dolor sit amet.",
        src: "../../audio/Oblivion-master.mp3",
    },
];
